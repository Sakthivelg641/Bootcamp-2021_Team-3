const Resume=() =>{

    return(
        <div>
            <h1>Resume Uploading Page</h1>
        </div>

    );
};

export default Resume;